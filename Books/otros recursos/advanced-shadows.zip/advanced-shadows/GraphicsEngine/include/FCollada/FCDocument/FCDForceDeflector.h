/*
	Copyright (C) 2005-2007 Feeling Software Inc.
	Portions of the code are:
	Copyright (C) 2005-2007 Sony Computer Entertainment America
	
	MIT License: http://www.opensource.org/licenses/mit-license.php
*/

/**
	@file FCDForceDeflector.h
	This file contains the FCDForceDeflector class.
*/

#ifndef _FCD_FORCE_DEFLECTOR_H_
#define _FCD_FORCE_DEFLECTOR_H_

#endif // _FCD_FORCE_DEFLECTOR_H_
